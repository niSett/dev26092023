<?php 

use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing;

$routes->add('leap_year', new Routing\Route('/is_leap_year/{year}', [
    'year' => null,
    '_controller' => 'LeapYearController::index',
]));

return $routes;

?>